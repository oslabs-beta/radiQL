# radiQL
Generates a GraphQL schema based on your previous REST Api routes
