
//uris type 
export type Uris = {
  uri_name: string;
  user_id: string
  }; 

//Response types
export type usersUris = {
  data: Uris[];
};
