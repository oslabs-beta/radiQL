/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./client/React.{html,js,tsx}'],
  theme: {
    extend: {},
  },
  plugins: [],
}
